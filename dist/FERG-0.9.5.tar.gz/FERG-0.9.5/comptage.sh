#! /bin/sh
cd /opt/FERG
python comptage.py
