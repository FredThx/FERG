#! /bin/sh
cd /opt/FERG
python rf_temp_io.py
