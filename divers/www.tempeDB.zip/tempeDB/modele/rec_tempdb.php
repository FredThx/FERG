<?php


/////////////////////////////////////////////////////
//Fonctions pour enregistrement des valeurs
////////////////////////////////////////////////////

function rec_mesure($capteur, $date, $temperature){
	global $bdd;
	$sql = "SELECT min, max FROM capteurs WHERE nom = :capteur";
	$params = array('capteur' => $capteur);
	$req = $bdd->prepare($sql);
	$req->execute($params);
	$min_max = $req->fetch();
	if ($min_max['min'] < $temperature and $temperature < $min_max['max']){
		$sql = "INSERT INTO mesures (capteur, date, temperature) "
				."VALUES (:capteur, :date, :temperature)";
		$params = array('capteur' => $capteur,'date' => $date, 'temperature' => $temperature);
		$req = $bdd->prepare($sql);
		return $req->execute($params);
	}
	else {
		mylogger('Erreur enregistrement temperature '.$capteur.' le '.$date.' : '.$temperature.'  :: out of range '.$min_max);
		return False;
	}
}

function rec_conso_electrique($circuit, $date_debut, $date_fin, $energie, $puissance, $type_horaire=NULL, $compteur=NULL){
	global $bdd;
	$sql = "INSERT INTO consos_electrique SET circuit = :circuit, date_debut = :date_debut, date_fin = :date_fin, energie = :energie, puissance = :puissance, type_horaire = :type_horaire, compteur = :compteur";
	$params = array('circuit' => $circuit,
					'date_debut' => $date_debut,
					'date_fin' => $date_fin,
					'energie' => $energie,
					'puissance' => $puissance,
					'type_horaire' => $type_horaire,
					'compteur' => $compteur);
	$req = $bdd->prepare($sql);
	return $req->execute($params);
}
