<?php
/*
Script principal de tempeDB
	par FredThx
	
	Utilisation : enregistrer des donn�es dans la base tempeDB
	� partir de requetes GET du type :
		http:192.168.10.10/tempeDB?table=mesures&champ1=xxx&champ2=xxx&...
		
	
	
Ici :	- connection � la base MySQL
		-

Puis on passe la main au controleurs.

*/
include_once('utils/mylogger.php');
include_once('modele/connection_sql.php');
include_once('modele/rec_tempdb.php');

//On fait tout � la main, mais ce serait bien d'automatiser en lisant la base....
if (isset($_GET['table'])){
	switch ($_GET['table']){
		case "mesures":
			if (isset($_GET['capteur']) and isset($_GET['temperature'])){
				if (isset($_GET['date'])){
					$date = $_GET['date'];
				}else{
					$date = date('Y-m-d H:i:s');
				}
				$result = rec_mesure($_GET['capteur'], $date, $_GET['temperature']);
			}else{
				$result = False;
			}
			break;
		case "consos_electrique":
			if (isset($_GET['circuit'])){
				if (isset($_GET['date_debut'])){
					$date_debut = $_GET['date_debut'];
				}else{
					$date_debut = date();
				}
				if (isset($_GET['date_fin'])){
					$date_fin = $_GET['date_fin'];
				}else{
					$date_fin = $date_debut;
				}
				if (isset($_GET['energie'])){
					$energie = $_GET['energie'];
				}else{
					$energie = 0;
				}
				if (isset($_GET['puissance'])){
					$puissance = $_GET['puissance'];
				}else{
					$puissance = 0;
				}
				if (isset($_GET['compteur'])){
					$compteur = $_GET['compteur'];
				}else{
					$compteur = NULL;
				}
				if (isset($_GET['type_horaire'])){
					$type_horaire = $_GET['type_horaire'];
				}else{
					$type_horaire = NULL;
				}
				$result = rec_conso_electrique($_GET['circuit'], $date_debut, $date_fin, $energie, $puissance, $type_horaire, $compteur);
			}else{
				$result = False;
			}
			break;
		default:
			$result = False;
		}
}else{
	$result = False;
}

if ($result){
	echo "OK";
}else{
	echo "ERROR";
}

?>

