<?php


function ClauseWhere($args){
	if (is_array($args) AND isset($args) AND count($args)>0){
		return " WHERE " . implode(" AND ", $args);
	} else{
		return "";
	}
}

function securise($tab){
	global $bdd;
	if (is_array($tab)){
		$result = [];
		foreach ($tab as $cle => $elt){
			if (is_array($elt)){
				$result[$cle] = securise($elt);
			} else {
				if (is_string($elt)){
					$result[$cle] = stripslashes(strip_tags($elt));
				} else {
					$result[$cle] = $elt;
				}
			}
		}
	} elseif (is_string($tab)){
		$result = stripslashes(strip_tags($tab));
	} else {
		$result = NULL ; 
	}
	//echo $tab.'===>'. $result . '<br/>';
	return $result;
}

function echoPost(){
	echo '<pre>';
	echo '$_POST = ';	
	print_r($_POST);
	echo '</pre>';
}

function echoGet(){
	echo '<pre>';
	echo '$_GET = ';
	print_r($_GET);
	echo '</pre>';
}
function echoSession(){
	echo '$_SESSION = ';
	echo '<pre>';
	print_r($_SESSION);
	echo '</pre>';
}
function echoCookie(){
	echo '$_COOKIE = ';
	echo '<pre>';
	print_r($_COOKIE);
	echo '</pre>';
}

