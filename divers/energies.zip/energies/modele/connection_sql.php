<?php

try{
	$bdd = new PDO('mysql:host=192.168.10.10;dbname=tempeDB', 'invite', '');
}
	catch (Exception $e)
{
		die('Erreur : ' . $e->getMessage());
}
