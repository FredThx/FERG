<?php

include_once('utils/utils_sql.php');

/////////////////////////////////////////////////////
//Fonctions pour acces SQL aux températures enregistrée.
////////////////////////////////////////////////////


function get_histo($circuit,$date_debut=NULL,$date_fin=NULL){
	global $bdd;
	$sql = "SELECT date_debut, puissance FROM consos_electrique WHERE circuit = :circuit";
	$params = array('circuit' => $circuit);
	if (isset($date_debut) and $date_debut != ''){
		$sql .= " AND date_debut > :date_debut";
		$params['date_debut'] = $date_debut;
	}
	if (isset ($date_fin) and $date_fin !=''){
		$sql .= " AND date_debut < :date_fin";
		$params['date_fin'] = $date_fin;
	}
	$sql .= " ORDER BY date_debut";
	$sql .= ";";
	//echo $sql;
	//print_r($params);
	//TODO : mettre une LIMIT
	$mesures = $bdd->prepare($sql);
	$mesures->execute($params);
	return $mesures;
}
function get_circuits(){
	global $bdd;
	$sql = "SELECT DISTINCTROW circuit FROM `consos_electrique`";
	$circuits = $bdd->prepare($sql);
	$circuits->execute();
	$les_circuits = array();
	while ($donnees=$circuits->fetch()){
		$les_circuits[]=$donnees['circuit'];
	}		
	return $les_circuits;
}

function get_histo_power($circuit,$periode="day", $date_debut=NULL,$date_fin=NULL){
	global $bdd;
	switch($periode){
		case "heure":
			$format = "'%Y-%m-%d : %H:00'";
			break;
		case "jour":
			$format = "'%Y-%m-%d'";
			break;
		case "semaine":
			$format = "'%Y.%u'";
			break;
		case "mois":
			$format = "'%Y-%m'";
			break;
		case "an":
			$format = "'%Y'";
	}
	$sql = "SELECT DATE_FORMAT(date_debut,".$format.") as date, SUM(energie) as s_energie FROM consos_electrique WHERE circuit = :circuit";
	$params = array('circuit' => $circuit);//, 'format' => $format);
	if (isset($date_debut) and $date_debut != ''){
		$sql .= " AND date_debut > :date_debut";
		$params['date_debut'] = $date_debut;
	}
	if (isset ($date_fin) and $date_fin !=''){
		$sql .= " AND date_debut < :date_fin";
		$params['date_fin'] = $date_fin;
	}
	$sql .= " GROUP BY DATE_FORMAT(date_debut,".$format.");";
	//echo $sql;
	//print_r($params);
	//TODO : mettre une LIMIT
	$mesures = $bdd->prepare($sql);
	//$mesures = $bdd->query($sql);
	$mesures->execute($params);
	return $mesures;
}