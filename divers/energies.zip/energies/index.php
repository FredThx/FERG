<?php
/*
Script principal de energies
	par FredThx
	
Ici :	- connection � la base MySQL
		-

Puis on passe la main au controleurs.

*/

include_once('modele/connection_sql.php');
include_once('utils/utils_sql.php');
include_once('modele/get_compteur.php');


if (isset($_GET['circuit'])){
	switch ($_GET['type_graphique']){
		case "puissance_instantanee":
			$histo = get_histo($_GET['circuit'],$_GET['date_debut'],$_GET['date_fin']);
			break;
		case "energie_consommee":
			$histo = get_histo_power($_GET['circuit'],$_GET['periode'],$_GET['date_debut'],$_GET['date_fin']);
			}
		//print_r($histo->fetchAll());
	}else{
		$histo = array();
}

$circuits = get_circuits();

include_once('vue/energies.php');