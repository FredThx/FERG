<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="energies.css" />
		<title>L'electricité ne se consomme pas toute seule !!!</title>
		<script type="text/javascript" src="js/dygraph-combined-dev.js"></script>
		<script type="text/javascript" src="js/dygraphs_barChartPlotter.js"></script>
	</head>

	<body>
		<div id="bloc_page">
			<header>
				<h1>L'electricité ne se consomme pas toute seule !!!</h1>
			</header>
			<nav>
				<h3>Extraction des consommations:</h3>
				<form method="get" action="index.php" id="Extraction">
					<p>
						<label for "liste_circuits">Circuit electrique</label><br/>
						<select name="circuit" id = "liste_circuits">
							<?php
							foreach ($circuits as $circuit){
								?>
								<option value = 
								<?php 
									echo '"'.$circuit.'"';
									if ($_GET['circuit']==$circuit){
										echo 'selected = "selected"';
									}
									echo '>'.$circuit;
								?></option>
								<?php
							}
							?>
						</select>
					</p>
					<p>
						<label for "date_debut">Date de début :</label><br/>
						<input type = "date" name = "date_debut" id = "date_debut" 
							<?php
								if (isset($_GET['date_debut'])){
									echo 'value="'.$_GET['date_debut'].'"';
								}
							?>>
					</p>
					<p>
						<label for "date_fin">Date de fin :</label><br/>
						<input type = "date" name = "date_fin" id = "date_fin"
						<?php
								if (isset($_GET['date_fin'])){
									echo 'value="'.$_GET['date_fin'].'"';
								}
							?>>
					</p>
					<p>
						Type de données:<br/>
						<input type="radio" name="type_graphique" id="puissance_instantanee" value = "puissance_instantanee" onClick="cachePeriode();"/> <label for "puissance_instantanee">Puissance instantanée</label><br/>
						<input type="radio" name="type_graphique" id="energie_consommee" value = "energie_consommee" onClick="affichePeriode();" /> <label for "energie_consommee">Energie consommée</label><br/>
						<div id="choixPeriode">
						Période:<br/>
							<input type="radio" name="periode" id="heure" value="heure"  /> <label for "heure">par heure</label><br/>
							<input type="radio" name="periode" id="jour" value = "jour"/> <label for "jour">par jour</label><br/>
							<input type="radio" name="periode" id="semaine" value = "semaine"/> <label for "semaine">par semaine</label><br/>
							<input type="radio" name="periode" id="mois" value = "mois"/> <label for "mois">par mois</label><br/>
							<input type="radio" name="periode" id="an" value = "an"/> <label for "an">par année</label><br/>
						</div>
					<p>
					<input type="submit" value="Extraction" />
				</form>
			</nav>
			<section>
				<article id="bloc_resultats">
					<div id = "graphe"></div>
				</article>
			</section>
		</div>
	</body>
	<script language="javascript" type="text/javascript">
		g = new Dygraph(document.getElementById("graphe"),
			 [
			 <?php
				foreach ($histo as $mesure){
					switch ($_GET['type_graphique']){
						case "puissance_instantanee":
							echo "[ new Date('".$mesure['date_debut']."'), ".$mesure['puissance']."],\n";
							break;
						case "energie_consommee":
							switch ($_GET['periode']){
								case 'semaine':
									echo "[ ".$mesure['date'].", ".$mesure['s_energie']."],\n";
									break;
								case 'an':
									echo "[ ".$mesure['date'].", ".$mesure['s_energie']."],\n";
									break;
								default:
									echo "[ new Date('".$mesure['date']."'), ".$mesure['s_energie']."],\n";
							}
					}
				}
			?>
			],
			 {
				 labels: ['Date', '<?php 
					if (isset($_GET['circuit'])){
						echo $_GET['circuit'];
					}?>'],
				 legend: 'always',
				 includeZero: true,
				 animatedZooms: true,
				 <?php
					if ($_GET['type_graphique']=='energie_consommee'){
						echo "plotter: barChartPlotter,\n";
					}
				?>
				 title: 'Des Watts , des Watts, des Watts.'
			 }
		);
	// Gestion de l'affichage des sous boutons choix periode)
	if ('<?php echo $_GET['type_graphique']?>' != 'energie_consommee'){
		document.getElementById("choixPeriode").style.display = "none";
		document.getElementById("puissance_instantanee").checked = true;
	}else{
		document.getElementById("energie_consommee").checked = true;
		document.getElementById("<?php echo $_GET['periode']?>").checked = true;
	}
	
	function cachePeriode(){
		document.getElementById("choixPeriode").style.display = "none";
	}
	function affichePeriode(){
		document.getElementById("choixPeriode").style.display = "block";
	}
	</script>
</html>